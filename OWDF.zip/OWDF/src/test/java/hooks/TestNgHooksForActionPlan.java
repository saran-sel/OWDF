package hooks;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import services.WebDriverServiceImpl;
import utils.DataInputProvider;

public class TestNgHooksForActionPlan extends WebDriverServiceImpl{

	public String product;
	public String origin;
	public String fg;

	@BeforeSuite
	public void beforeSuite() {
		startReport();
	}

	@BeforeClass
	public void beforeClass() {
		startTestCase(testCaseName, testDescription);		
	}

	@BeforeMethod
	public void beforeMethod() throws FileNotFoundException, IOException {
			
		startTestcase(nodes);		

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		System.setProperty("webdriver.chrome.silentOutput", "true");
		ChromeOptions options = new ChromeOptions();

		if(properties.getProperty("Headless").equalsIgnoreCase("true"))
			options.setHeadless(true);

		webdriver = new ChromeDriver(options);
		driver = new EventFiringWebDriver(webdriver);
		driver.register(this);

		tlDriver.set(driver);		
		getDriver().manage().window().maximize();
		//properties.load(new FileInputStream(new File("./environment.properties")));

		getDriver().get(properties.getProperty("URL"));
		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


	}

	@BeforeMethod()
	public void startLogin() {

		String parentWindow = getParentHandle();
		click(getDriver().findElement(By.xpath(locators.getProperty("HomePage.LoginButton.Xpath"))));
		sleep(3000);
	
		switchToWindow(1);
		
		type(getDriver().findElement(By.name(locators.getProperty("LoginPage.Username.name"))),
				properties.getProperty("UserName"));
		click(getDriver().findElement(By.xpath(locators.getProperty("LoginPage.Next.Xpath"))));
		
		click(getDriver().findElement(By.id(locators.getProperty("LoginPage.FormClick.Id"))));

		typeAndEnter(getDriver().findElement(By.id(locators.getProperty("LoginPage.Password.Id"))),
				properties.getProperty("Password"));
		
		goBackToParentWindow(parentWindow);
		
		sleep(3000);
		
	}


	@AfterMethod
	public void afterMethod() {
		sleep(10000);
		closeActiveBrowser();
	}

	@AfterSuite
	public void afterSuite() {
		
		endResult();
	}

	@DataProvider(name="fetchData", parallel=true)
	public  Object[][] getData(){
		return DataInputProvider.getSheet(dataSheetName);		
	}	
	
	
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getFg() {
		return fg;
	}

	public void setFg(String fg) {
		this.fg = fg;
	}


}
