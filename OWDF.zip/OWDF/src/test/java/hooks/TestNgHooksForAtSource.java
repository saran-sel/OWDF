package hooks;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import services.WebDriverServiceImpl;
import utils.DataInputProvider;

public class TestNgHooksForAtSource extends WebDriverServiceImpl{
	

	@BeforeSuite
	public void beforeSuite() {
		startReport();
	}

	@BeforeClass
	public void beforeClass() {
		startTestCase(testCaseName, testDescription);		
	}

	@BeforeMethod
	public void beforeMethod() throws FileNotFoundException, IOException {
			
		startTestcase(nodes);		

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		System.setProperty("webdriver.chrome.silentOutput", "true");
		ChromeOptions options = new ChromeOptions();

		if(properties.getProperty("Headless").equalsIgnoreCase("true"))
			options.setHeadless(true);

		webdriver = new ChromeDriver(options);
		driver = new EventFiringWebDriver(webdriver);
		driver.register(this);

		tlDriver.set(driver);		
		getDriver().manage().window().maximize();
		//properties.load(new FileInputStream(new File("./environment.properties")));

		getDriver().get(properties.getProperty("AtSourceURL"));
		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


	}

	@BeforeMethod()
	public void startLogin() {

		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.HomePage.LoginButton.Xpath"))));
		type(getDriver().findElement(By.id(locators.getProperty("AtSource.LoginPage.Username.Id"))),
				properties.getProperty("AtSourceGodUser"));
		type(getDriver().findElement(By.id(locators.getProperty("AtSource.LoginPage.Password.Id"))),
				properties.getProperty("AtSourceGodUserPassword"));
		switchToFrame(getDriver().findElement(By.xpath(locators.getProperty("AtSource.LoginPage.SwitchFrame.Xpath"))));
		System.out.println("inside f");
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.LoginPage.CaptchaCheckBox.Xpath"))));
		switchOutOfFrame();
		sleep(5000);
		click(getDriver().findElement(By.id(locators.getProperty("AtSource.LoginPage.LoginButton.Id"))));
		
	}


	@AfterMethod
	public void afterMethod() {
		purgeDirectoryOn(100);
		closeActiveBrowser();
	}

	@AfterSuite
	public void afterSuite() {
		endResult();
	}

	@DataProvider(name="fetchData", parallel=true)
	public  Object[][] getData(){
		return DataInputProvider.getSheet(dataSheetName);		
	}	





}
