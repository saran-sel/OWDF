package services;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;

public class AtSourceValidations {

	public ArrayList<Object> getKMDesc = new ArrayList<Object>();
	


	public  static List<HashMap<String, Object>> getExcelData(String fileName){
		List<HashMap<String, Object>> ret = new ArrayList<>();
		List<String> headings = new ArrayList<String>();
		try{
			Object temp=null;
			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
			int row = sheet.getLastRowNum();
			HashMap<String, Object> tempMap = null;
			int cellType = 0;
			int columnCount = sheet.getRow(0).getLastCellNum();


			for (int i = 0; i < row; i++) {
				tempMap = new HashMap<>();
				for (int j =0; j < columnCount; j++) {
					if(i==0) {
						headings.add(sheet.getRow(0).getCell(j).getStringCellValue());
					}else {
						temp = "";
						if(sheet.getRow(i).getCell(j) != null ) {
							cellType = sheet.getRow(i).getCell(j).getCellType().getCode();
							if(cellType == CellType.NUMERIC.getCode()) {
								temp = sheet.getRow(i).getCell(j).getNumericCellValue();
							}else {
								temp = sheet.getRow(i).getCell(j).getStringCellValue();
							}
						}
						tempMap.put(headings.get(j), temp.toString());
					}
				}
				if(i > 0) {
					ret.add(tempMap);
				}
			}
			workbook.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return ret;
	}

	public static List<HashMap<String, Object>> filterExcelList(List<HashMap<String, Object>> list,HashMap<String, String> filterValues) {
		return list.stream().filter(map -> 
		{
			return filterValues.entrySet().stream().filter(m -> map.get(m.getKey()).equals(m.getValue())).count() == filterValues.size();
		}).collect(Collectors.toList());
	}
	public static void main(String[] args) {
		System.out.println(returnvalueForKey("Cashew","AGBELOBA (ORA) CPF", "OLAM VIETNAM LIMITED-DAK NONG-VIETNAM","CC-TOTAL"));
	}

	public static Object returnvalueForKey(String product,String farmerGroup,String destination,String key) {
		HashMap<String, String> filterValues = new HashMap<>();
		filterValues.put("Product", product);
		filterValues.put("FarmerGroup_Estate", farmerGroup);
		filterValues.put("Destination", destination);
		return filterExcelList(getExcelData("./test.xlsx"), filterValues).get(0).get(key);
	}

	public ArrayList<String> getListOfProductsFromExcel() {
		HashSet<String> listOfProducts = null;
		ArrayList<String> convertToList = null;
		try {
			File file = new File("./data/test.xlsx");
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
			String product;
			listOfProducts = new HashSet<>();

			for (int i = 1; i < sheet.getLastRowNum(); i++) {
				product = sheet.getRow(i).getCell(3).getStringCellValue();
				listOfProducts.add(product);
			}

			listOfProducts.remove("Almond");
			listOfProducts.remove("Dairy");
			listOfProducts.remove("Pepper");

			/*System.out.println("*******************");

			Iterator ite = listOfProducts.iterator();
			while(ite.hasNext()) {
				System.out.println(ite.next());
			}*/
			convertToList = convertToList(listOfProducts);
			Collections.sort(convertToList);

		}catch(Exception e) {
			e.printStackTrace();
		}
		return convertToList;
	}

	public static <T> ArrayList<T> convertToList(Set<T> set)
	{
		// create an empty list
		ArrayList<T> items = new ArrayList<>();

		// push each element in the set into the list
		for (T e : set)
			items.add(e);

		// return the list
		return items;
	}

	public int getRandomPercentage() {

		double randNumber = Math.random();
		double	d = randNumber * 100;
		int randomInt = (int)d +1;

		return randomInt;


	}




	public HashMap<String, HashMap<String,HashMap<String, String>>> getExcelKMValues() {
		HashMap<String, HashMap<String,HashMap<String, String>>> output = new HashMap<>();
		try {
			//String text = "D:\\Users\\sgnanasekar4048\\Desktop\\FarmerSummarySheet.xlsx";
			String text = getLastModified("./data").toString();
			System.out.println(text);
			FileInputStream fis = new FileInputStream(text);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			int sheetNo = workbook.getNumberOfSheets();
			XSSFSheet sheet = null;
			HashMap<String,HashMap<String,HashMap<String, String>>> temp = null;
			HashMap<String, String> kmMap;
			HashMap<String,HashMap<String, String>> kmList;
			System.out.println(sheetNo);
			for(int sn = 0; sn < sheetNo;sn++) {
				temp = new HashMap<String,HashMap<String,HashMap<String, String>>>();
				kmList = new HashMap<String,HashMap<String,String>>();
				// get the number of rows
				sheet = workbook.getSheetAt(sn);
				int rowCount = sheet.getLastRowNum();
				// loop through the rows
				for(int i=2; i <rowCount+1; i++){
					kmMap = new HashMap<String, String>();
					XSSFRow row = sheet.getRow(i);
					String cellValue = "";
					cellValue = row.getCell(1).getStringCellValue();
					kmMap.put("title", cellValue);
					cellValue = row.getCell(2).getStringCellValue();
					kmMap.put("desc", cellValue);
					kmList.put(row.getCell(0).getStringCellValue()+"_"+i, kmMap);
				}
				output.put(sheet.getSheetName(), kmList);
			}
			System.out.println(output);
			fis.close();
			workbook.close();
			//			System.out.println(
			//					getValuesBasedOnKM("PROSPEROUS FARMERS & FOOD SYSTE",
			//							"Farmers in a farmer group trained on health & safety practices", "title"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	public String getValuesBasedOnKM(HashMap<String, HashMap<String,HashMap<String, String>>> output,String tab,String km, String key) {
		Set<String> tabs = output.keySet();
		for(String t : tabs) {
			if(t.contains(tab)) {
				tab = t;
				break;
			}
		}
		tabs = output.get(tab).keySet();
		for(String t : tabs) {
			if(t.contains(km)) {
				km = t;
				break;
			}
		}
		return output.get(tab).get(km).get(key).toString();
	}

	public boolean findMatchForTitleDesc(HashMap<String, HashMap<String,HashMap<String, String>>> output,String tab,String km,String title,String desc) {
		Set<String> tabs = output.keySet();
		boolean ret = false;
		for(String t : tabs) {
			if(t.contains(tab)) {
				tab = t;
				break;
			}
		}
		tabs = output.get(tab).keySet();
		for(String t : tabs) {
			if(t.contains(km)) {
				if(output.get(tab).get(t).get("title").equals(title) && output.get(tab).get(t).get("desc").equals(desc)) {
					ret = true;
					break;
				}else {
					continue;
				}
			}
		}
		return ret;
	}

	public static File getLastModified(String directoryFilePath)
	{
		File directory = new File(directoryFilePath);
		File[] files = directory.listFiles(File::isFile);
		long lastModifiedTime = Long.MIN_VALUE;
		File chosenFile = null;

		if (files != null)
		{
			for (File file : files)
			{
				if (file.lastModified() > lastModifiedTime)
				{
					chosenFile = file;
					lastModifiedTime = file.lastModified();
				}
			}
		}

		return chosenFile;
	}



	public ArrayList<String> getListOfKMBasedOnSheetName(String sheetName) {

		ArrayList<String> kmList = null ;
		try {
			kmList = new ArrayList<>();
			File file = new File(getLastModified("./data").toString());
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			for (int i = 2; i <= sheet.getLastRowNum(); i++) {

				String kmValue = sheet.getRow(i).getCell(0).getStringCellValue();
				kmList.add(kmValue);
			}


		}catch(Exception e) {
			e.printStackTrace();

		}
		return kmList;
	}

	public HashMap<String, String> getSupplyChainFromExcel() {

		HashMap<String, String> supplyChain = null;

		try {
			String product;
			String origin;
			String fg;

			supplyChain = new HashMap<>();

			File file = new File(getLastModified("./data").toString());
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);

			product = sheet.getRow(0).getCell(0).getStringCellValue();
			origin = sheet.getRow(0).getCell(1).getStringCellValue();
			fg = sheet.getRow(0).getCell(2).getStringCellValue();

			supplyChain.put("product", product);
			supplyChain.put("origin", origin);
			supplyChain.put("fg", fg);

		}catch(Exception e) {
			e.printStackTrace();
		}
		return supplyChain;
	}

	public boolean verifyKMfromExcel(List<WebElement> textLstToCheck,String product, String origin, String fg) {
		boolean returnVal = false;
		AtSourceValidations atsourceValidations = new AtSourceValidations();
		List<HashMap<String, Object>> fgCompleteData = atsourceValidations.getExcelData("./reference/FG.xlsx");
		List<HashMap<String, Object>> kmDetailsData = atsourceValidations.getExcelData("./reference/KMDetails.xlsx");
		for (WebElement text : textLstToCheck) {
			returnVal = false;
			for(HashMap<String, Object> map : fgCompleteData) {
				if(map.get("PRODUCT").equals(product) && map.get("Origin").equals(origin) && map.get("FARMERGROUP").equals(fg)) {
					for(String km : map.keySet()) {
						if(km.contains("-") && map.get(km)!= null && !map.get(km).toString().isEmpty()) {
							for(HashMap<String, Object> temp : kmDetailsData) {
								if(!returnVal && temp.get("KMNomeClature").toString().equals(km)) {
									if(temp.get("KMDescription").equals(text.getText())) {
										returnVal = true;
									}
								}
							}
							if(!returnVal) {
								return false;
							}
						}
					}
				}
			}
		}
		return returnVal;
	}

}
