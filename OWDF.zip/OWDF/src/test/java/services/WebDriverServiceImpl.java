package services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import design.WebDriverService;
import events.WebDriverEvents;

public class WebDriverServiceImpl extends WebDriverEvents implements WebDriverService{

	AtSourceValidations atsourceValidations = new AtSourceValidations();
	ArrayList<String> getKMDesc = new ArrayList<>();

	static String currentTimeMillis = null;

	public WebElement locateElement(String locator, String locValue) {

		try {
			switch (locator) {
			case "id": return getDriver().findElement(By.id(locValue));
			case "name": return getDriver().findElement(By.name(locValue));
			case "class": return getDriver().findElement(By.className(locValue));
			case "link" : return getDriver().findElement(By.linkText(locValue));
			case "xpath": return getDriver().findElement(By.xpath(locValue));		
			default: break;
			}

		} catch (NoSuchElementException e) {
			reportStep("The element with locator "+locator+" not found.","FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while finding "+locator+" with the value "+locValue, "FAIL");
		}
		return null;
	}

	public WebElement locateElement(String locValue) {
		return getDriver().findElement(By.id(locValue));
	}

	public void type(WebElement ele, String data) {
		try {
			ele.clear();
			ele.sendKeys(data);
			reportStep("The data: "+data+" entered successfully in the field :"+ele, "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The data: "+data+" could not be entered in the field :"+ele,"FAIL");
		} catch (WebDriverException e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while entering "+data+" in the field :"+ele, "FAIL");
		}
	}

	public void typeAndChoose(WebElement ele, String data) {
		try {
			ele.clear();
			ele.sendKeys(data, Keys.TAB);
			reportStep("The data: "+data+" entered successfully in the field :"+ele, "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The data: "+data+" could not be entered in the field :"+ele,"FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while entering "+data+" in the field :"+ele, "FAIL");
		}
	}

	public void typeAndEnter(WebElement ele, String data) {
		try {
			ele.clear();
			ele.sendKeys(data, Keys.ENTER);
			//reportStep("The data: "+data+" entered successfully in the field :"+ele, "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The data: "+data+" could not be entered in the field :"+ele,"FAIL");
		} catch (WebDriverException e) {
			e.printStackTrace();
			reportStep("Unknown exception occured while entering "+data+" in the field :"+ele, "FAIL");
		}
	}

	public void click(WebElement ele) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(), 10);
			wait.until(ExpectedConditions.elementToBeClickable(ele));			
			text = ele.getText();
			ele.click();
			reportStep("The element "+text+" is clicked", "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The element: "+text+" could not be clicked", "FAIL");
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while clicking in the field :", "FAIL");
		} 
	}

	public void sleep(long millis) {
		try {
			Thread.sleep(millis);
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

	public void clickWithNoSnap(WebElement ele) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(), 10);
			wait.until(ExpectedConditions.elementToBeClickable(ele));	
			text = ele.getText();
			ele.click();			
			reportStep("The element :"+text+"  is clicked.", "PASS",false);
		} catch (InvalidElementStateException e) {
			reportStep("The element: "+text+" could not be clicked", "FAIL",false);
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while clicking in the field :","FAIL",false);
		} 
	}

	public String getText(WebElement ele) {	
		String bReturn = "";
		try {
			bReturn = ele.getText();
			reportStep("The element has the web value: "+bReturn, "PASS");
		} catch (WebDriverException e) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
		}
		return bReturn;
	}

	public String getTitle() {		
		String bReturn = "";
		try {
			bReturn =  getDriver().getTitle();
		} catch (WebDriverException e) {
			reportStep("Unknown Exception Occured While fetching Title", "FAIL");
		} 
		return bReturn;
	}

	public String getAttribute(WebElement ele, String attribute) {		
		String bReturn = "";
		try {
			bReturn=  ele.getAttribute(attribute);
		} catch (WebDriverException e) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
		} 
		return bReturn;
	}

	public void selectDropDownUsingVisibleText(WebElement ele, String value) {
		try {
			new Select(ele).selectByVisibleText(value);
			reportStep("The dropdown is selected with text "+value,"PASS");
		} catch (WebDriverException e) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
		}

	}

	public void selectDropDownUsingIndex(WebElement ele, int index) {
		try {
			new Select(ele).selectByIndex(index);
			reportStep("The dropdown is selected with index "+index,"PASS");
		} catch (WebDriverException e) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
		} 

	}

	public String getSelectedOption(WebElement ele) {

		String selectedOption = null;
		try {
			selectedOption = new Select(ele).getFirstSelectedOption().getText().trim();
			reportStep("The dropdown is selected with "+selectedOption,"PASS");
		}catch(WebDriverException e) {
			reportStep("The dropdown is not selected with "+selectedOption,"PASS");

		}
		return selectedOption;
	}

	public boolean verifyExactTitle(String title) {
		boolean bReturn =false;
		try {
			if(getTitle().equals(title)) {
				reportStep("The title of the page matches with the value :"+title,"PASS");
				bReturn= true;
			}else {
				reportStep("The title of the page:"+getDriver().getTitle()+" did not match with the value :"+title, "FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the title", "FAIL");
		} 
		return bReturn;
	}

	public boolean verifyPartialTitle(String title) {
		boolean bReturn =false;
		try {
			if(getTitle().contains(title)) {
				reportStep("The title of the page matches with the value :"+title,"PASS");
				bReturn= true;
			}else {
				reportStep("The title of the page:"+getDriver().getTitle()+" did not match with the value :"+title, "FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the title", "FAIL");
		} 
		return bReturn;		
	}

	public void verifyExactText(WebElement ele, String expectedText) {
		try {
			if(getText(ele).equals(expectedText)) {
				reportStep("The text: "+getText(ele)+" matches with the value :"+expectedText,"PASS");
			}else {
				reportStep("The text "+getText(ele)+" doesn't matches the actual "+expectedText,"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Text", "FAIL");
		} 

	}

	public void verifyPartialText(WebElement ele, String expectedText) {
		try {
			if(getText(ele).contains(expectedText)) {
				reportStep("The expected text contains the actual "+expectedText,"PASS");
			}else {
				reportStep("The expected text doesn't contain the actual "+expectedText,"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Text", "FAIL");
		} 
	}

	public void verifyExactAttribute(WebElement ele, String attribute, String value) {
		try {
			if(getAttribute(ele, attribute).equals(value)) {
				reportStep("The expected attribute :"+attribute+" value matches the actual "+value,"PASS");
			}else {
				reportStep("The expected attribute :"+attribute+" value does not matches the actual "+value,"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Attribute Text", "FAIL");
		} 

	}

	public void verifyPartialAttribute(WebElement ele, String attribute, String value) {
		try {
			if(getAttribute(ele, attribute).contains(value)) {
				reportStep("The expected attribute :"+attribute+" value contains the actual "+value,"PASS");
			}else {
				reportStep("The expected attribute :"+attribute+" value does not contains the actual "+value,"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Attribute Text", "FAIL");
		}
	}

	public void verifySelected(WebElement ele) {
		try {
			if(ele.isSelected()) {
				reportStep("The element "+ele+" is selected","PASS");
			} else {
				reportStep("The element "+ele+" is not selected","FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		}
	}

	public void verifyDisplayed(WebElement ele) {
		try {
			if(ele.isDisplayed()) {
				reportStep("The element "+ele+" is visible","PASS");
			} else {
				reportStep("The element "+ele+" is not visible","FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		} 
	}

	public String getParentHandle() {
		return   driver.getWindowHandle();

	}

	public void switchToWindow(int index) {
		try {
			Set<String> allWindowHandles = getDriver().getWindowHandles();
			System.out.println("Total windows: "+allWindowHandles.size());
			List<String> allHandles = new ArrayList<>();
			allHandles.addAll(allWindowHandles);
			getDriver().switchTo().window(allHandles.get(index));
		} catch (NoSuchWindowException e) {
			reportStep("The driver could not move to the given window by index "+index,"PASS");
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		}
	}

	public void goBackToParentWindow(String nameOrHandle) {
		try {
			driver.switchTo().window(nameOrHandle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void switchToFrame(WebElement ele) {
		try {
			getDriver().switchTo().frame(ele);
			reportStep("switch In to the Frame "+ele,"PASS");
		} catch (NoSuchFrameException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		} 
	}

	public void switchOutOfFrame() {
		try {
			getDriver().switchTo().defaultContent();
		}catch(WebDriverException e) {
			e.printStackTrace();
		}
	}

	public void acceptAlert() {
		String text = "";		
		try {
			Alert alert = getDriver().switchTo().alert();
			text = alert.getText();
			alert.accept();
			reportStep("The alert "+text+" is accepted.","PASS");
		} catch (NoAlertPresentException e) {
			reportStep("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		}  
	}

	public void dismissAlert() {
		String text = "";		
		try {
			Alert alert = getDriver().switchTo().alert();
			text = alert.getText();
			alert.dismiss();
			reportStep("The alert "+text+" is dismissed.","PASS");
		} catch (NoAlertPresentException e) {
			reportStep("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		} 

	}

	public String getAlertText() {
		String text = "";		
		try {
			Alert alert = getDriver().switchTo().alert();
			text = alert.getText();
		} catch (NoAlertPresentException e) {
			reportStep("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		} 
		return text;
	}

	public void closeActiveBrowser() {
		try {
			getDriver().close();
			reportStep("The browser is closed","PASS", false);
		} catch (Exception e) {
			reportStep("The browser could not be closed","FAIL", false);
		}
	}

	public void closeAllBrowsers() {
		try {
			getDriver().quit();
			reportStep("The opened browsers are closed","PASS", false);
		} catch (Exception e) {
			reportStep("Unexpected error occured in Browser","FAIL", false);
		}
	}

	public void selectDropDownUsingValue(WebElement ele, String value) {
		try {
			new Select(ele).selectByValue(value);
			reportStep("The dropdown is selected with text "+value,"PASS");
		} catch (WebDriverException e) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
		}

	}

	public ArrayList<String> getAllOptionsFromDropDown(WebElement ele) {

		List<WebElement> options = null;
		ArrayList<String> listOfProducts = new ArrayList<>();
		try {
			options = new Select(ele).getOptions();

			for (WebElement obj : options) {
				listOfProducts.add(obj.getText());
			}
			listOfProducts.remove("Product X");
			listOfProducts.remove("Product Y");
			listOfProducts.remove("Select a product");

			Collections.sort(listOfProducts);
			/*for (String tst : listOfProducts) {
				System.out.println(tst);
			}*/

			reportStep("All options from the dropdown is printed","PASS");
		}catch (WebDriverException e ) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
		}
		return listOfProducts;
	}

	public List<String> getListOfItemsFromDropDown(List<WebElement> list) {

		List<String> returnArr = new ArrayList<String>();
		try {
			for (WebElement obj : list) {
				returnArr.add(obj.getText());
			}

		}catch(Exception e) {
			e.printStackTrace();
		}
		return returnArr;
	}

	public void getOptionsAndSelectInSequence(String xpath) {

		try {


			click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.ProductDropdown.Id"))));
			List<WebElement> productOptions = getDriver().findElements(By.xpath(xpath));

			for (int i = 1; i <= productOptions.size(); i++) {
				click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.ProductDropdown.Id"))));
				getDriver().findElement(By.xpath("("+locators.getProperty("FarmerGroupPage.DropdownValues.Xpath")+")["+i+"]")).click();

				click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.OriginDropdown.Id"))));
				List<WebElement> originOptions = getDriver().findElements(By.xpath(xpath));

				for (int j = 1; j <= originOptions.size(); j++) {
					click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.OriginDropdown.Id"))));
					getDriver().findElement(By.xpath("("+locators.getProperty("FarmerGroupPage.DropdownValues.Xpath")+")["+j+"]")).click();

					click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.FGDropdown.Id"))));
					List<WebElement> fgOptions = getDriver().findElements(By.xpath(xpath));

					for (int k = 5; k <= fgOptions.size(); k++) {
						click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.FGDropdown.Id"))));
						getDriver().findElement(By.xpath("("+locators.getProperty("FarmerGroupPage.DropdownValues.Xpath")+")["+k+"]")).click();

						if(k==5) {
							break;
						}
					}

					if(j==1) {
						break;
					}
				}

				if(i==1) {
					break;
				}
			}

		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void getActionPlanExistingAndDelete() {

		try {
			List<WebElement> viewButtonCount = getDriver()
					.findElements(By.xpath(locators.getProperty("PillarsTab.ViewButton.Xpath")));

			for (int i = 1; i <= viewButtonCount.size(); i++) {

				sleep(3000);
				click(getDriver().findElement(
						By.xpath("(" + locators.getProperty("PillarsTab.ViewButton.Xpath") + ")[1]")));
				click(getDriver()
						.findElement(By.xpath(locators.getProperty("PillarsTab.DeleteButton.Xpath"))));
				click(getDriver()
						.findElement(By.xpath(locators.getProperty("PillarsTab.ConfirmDelete.Xpath"))));
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createActionPlanForAllKeyMetrics(String actionPlan,String product,String origin,String fg) {
		try {
			currentTimeMillis = currentTimeMillis == null ? new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date()) : currentTimeMillis;
			System.out.println("-----------current--"+currentTimeMillis);
			List<WebElement> addActionItems = getDriver()
					.findElements(By.xpath(locators.getProperty("PillarsTab.AddButton.Xpath")));
			File file = new File("./data/ActionPlan_Create-"+currentTimeMillis+".xlsx");
			FileInputStream io = null;
			XSSFWorkbook workbook;
			if(file.exists()) {
				System.out.println("If---"+actionPlan);
				io = new FileInputStream(file);
				workbook = new XSSFWorkbook(io);
			}else {
				System.out.println("else---"+actionPlan);
				workbook = new XSSFWorkbook();
			}
			XSSFSheet sheet = workbook.createSheet(actionPlan);
			int rowCount = 0;
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			Cell cell = row.createCell(columnCount++);
			cell.setCellValue(product);
			cell = row.createCell(columnCount++);
			cell.setCellValue(origin);
			cell = row.createCell(columnCount++);
			cell.setCellValue(fg);
			row = sheet.createRow(rowCount++);
			columnCount = 0;
			cell = row.createCell(columnCount++);
			cell.setCellValue("KM");
			cell = row.createCell(columnCount++);
			cell.setCellValue("Title");
			cell = row.createCell(columnCount++);
			cell.setCellValue("Description");

			System.out.println("plus button size is:"+addActionItems.size());
			//
			for (int i = 1; i <= addActionItems.size(); i++) {

				sleep(3000);				
				click(getDriver().findElement(By.xpath("(" + locators.getProperty("PillarsTab.AddButton.Xpath") + ")[" + "1" + "]")));
				String popUpText = getText(getDriver()
						.findElement(By.xpath(locators.getProperty("PillarsTab.GetPopUpTitle.Xpath"))));
				long timeStamp = System.currentTimeMillis();

				type(getDriver().findElement(By.name(locators.getProperty("PillarsTab.Title.name"))),
						popUpText);
				type(getDriver().findElement(By.name(locators.getProperty("PillarsTab.Percentage.name"))),
						String.valueOf(atsourceValidations.getRandomPercentage()));
				type(getDriver().findElement(By.name(locators.getProperty("PillarsTab.Description.name"))),
						String.valueOf(timeStamp));

				click(getDriver().findElement(By.id(locators.getProperty("PillarsTab.SelectCustomer.Id"))));
				click(getDriver()
						.findElement(By.xpath(locators.getProperty("PillarsTab.SelectAll.Xpath"))));

				click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Submit.Xpath"))));
				sleep(5000);
				click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.LastViewButton.Xpath"))));
				String enteredTitleName = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.GetEnteredTitle.Xpath"))));
				System.out.println(enteredTitleName);
				click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.CancelPopup.Xpath"))));
				row = sheet.createRow(rowCount++);;
				columnCount = 0;
				cell = row.createCell(columnCount++);
				cell.setCellValue(popUpText);
				cell = row.createCell(columnCount++);
				cell.setCellValue(enteredTitleName);
				cell = row.createCell(columnCount++);
				cell.setCellValue(String.valueOf(timeStamp));

			}
			if(io != null) {
				io.close();
			}
			FileOutputStream outputStream = new FileOutputStream(new File("./data/ActionPlan_Create-"+currentTimeMillis+".xlsx"));
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			System.out.println("---------write-----------");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void editActionPlanForAllKeyMetrics(String actionPlan,String product,String origin,String fg) {

		try {
			currentTimeMillis = currentTimeMillis == null ? new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date()) : currentTimeMillis;
			int actionPlanExisting = getDriver()
					.findElements(By.xpath(locators.getProperty("PillarsTab.ViewButton.Xpath"))).size();
			File file = new File("./data/ActionPlan_Edit-"+currentTimeMillis+".xlsx");
			FileInputStream io = null;
			XSSFWorkbook workbook;
			if(file.exists()) {
				System.out.println("If---"+actionPlan);
				io = new FileInputStream(file);
				workbook = new XSSFWorkbook(io);
			}else {
				System.out.println("else---"+actionPlan);
				workbook = new XSSFWorkbook();
			}
			XSSFSheet sheet = workbook.createSheet(actionPlan);
			int rowCount = 0;
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			Cell cell = row.createCell(columnCount++);
			cell.setCellValue(product);
			cell = row.createCell(columnCount++);
			cell.setCellValue(origin);
			cell = row.createCell(columnCount++);
			cell.setCellValue(fg);
			row = sheet.createRow(rowCount++);
			columnCount = 0;
			cell = row.createCell(columnCount++);
			cell.setCellValue("KM");
			cell = row.createCell(columnCount++);
			cell.setCellValue("Title");
			cell = row.createCell(columnCount++);
			cell.setCellValue("Description");

			System.out.println("view button size is:"+actionPlanExisting);
			//
			for (int i = 1; i <= actionPlanExisting; i++) {

				sleep(3000);				
				click(getDriver().findElement(By.xpath("(" + locators.getProperty("PillarsTab.ViewButton.Xpath") + ")["+i+"]")));
				String popUpText = getText(getDriver()
						.findElement(By.xpath(locators.getProperty("PillarsTab.GetPopUpTitle.Xpath"))));
				click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.EditButton.Xpath"))));
				long timeStamp = System.currentTimeMillis();

				type(getDriver().findElement(By.name(locators.getProperty("PillarsTab.Title.name"))),
						" AP_Edit_"+timeStamp);
				type(getDriver().findElement(By.name(locators.getProperty("PillarsTab.Percentage.name"))),
						String.valueOf(atsourceValidations.getRandomPercentage()));
				type(getDriver().findElement(By.name(locators.getProperty("PillarsTab.Description.name"))),
						"Action plan edit test_"+timeStamp);


				click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Submit.Xpath"))));
				sleep(5000);
				click(getDriver().findElement(By.xpath("(" + locators.getProperty("PillarsTab.ViewButton.Xpath") + ")["+i+"]")));
				String enteredTitleName = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.GetEnteredTitle.Xpath"))));
				String enteredDesc = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.GetEnteredDesc.Xpath"))));
				click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.CancelPopup.Xpath"))));
				row = sheet.createRow(rowCount++);;
				columnCount = 0;
				cell = row.createCell(columnCount++);
				cell.setCellValue(popUpText);
				cell = row.createCell(columnCount++);
				cell.setCellValue(enteredTitleName);
				cell = row.createCell(columnCount++);
				cell.setCellValue(enteredDesc);

			}
			if(io != null) {
				io.close();
			}
			FileOutputStream outputStream = new FileOutputStream(new File("./data/ActionPlan_Edit-"+currentTimeMillis+".xlsx"));
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			System.out.println("---------write-----------");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void verifyNonExistenceOfActionPlan(List<WebElement> ele) {

		try {
			int size = ele.size();
			if(size == 0) {
				reportStep("The element "+ele+" is not present","PASS");
			}else {
				reportStep("The element "+ele+" is present","FAIL");
			}
		} catch (Exception e) {
			reportStep("The element "+ele+" is present","FAIL");
			e.printStackTrace();
		}

	}

	public void deleteActionPlanForAllKeyMetrics() {

		getActionPlanExistingAndDelete();
	}

	public void purgeDirectoryOn(int maxFiles) {

		File file = new File("./data");
		int length = file.listFiles().length;

		if(length > maxFiles) {
			try {
				FileUtils.cleanDirectory(file);
			} catch (IOException e) {

				e.printStackTrace();
			} 
		}
	}

	
	@Override
	public void waitForLoaderToDisapper() {

		new WebDriverWait(getDriver(), Duration.ofSeconds(30))
		.until(ExpectedConditions.visibilityOfElementLocated(By
				.className(locators.getProperty("LoginPage.CaptchaSucess.ClassName"))));

	}



}
