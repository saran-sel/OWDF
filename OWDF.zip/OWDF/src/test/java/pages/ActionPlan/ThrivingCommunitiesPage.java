package pages.ActionPlan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooks.TestNgHooksForActionPlan;
import services.AtSourceValidations;

public class ThrivingCommunitiesPage extends TestNgHooksForActionPlan {
	
	AtSourceValidations atsourceValidations = new AtSourceValidations();

	public RegeneratingTheLivingWorldPage addActionPlanInThrivingCommunitiesPage() {

		sleep(3000);
		List<WebElement> KMsOnScreen = getDriver().findElements(By.xpath(locators.getProperty("ActionPlan.GetKMFromAP.Xpath")));
		boolean exist = atsourceValidations.verifyKMfromExcel(KMsOnScreen,getProduct(),getOrigin(),getFg());
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab3.Xpath"))));
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab3.Xpath"))));

		int actionPlanExisting = getDriver()
				.findElements(By.xpath(locators.getProperty("PillarsTab.ViewButton.Xpath"))).size();

		if(actionPlanExisting >= 1) {

			getActionPlanExistingAndDelete();
			createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());

		}else {
			createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());
		}
		
		return new RegeneratingTheLivingWorldPage();
	}

	public RegeneratingTheLivingWorldPage editActionPlanInThrivingCommunitiesPage() {
		
		sleep(3000);
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab3.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab3.Xpath"))));
		
		editActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());

		return new RegeneratingTheLivingWorldPage();

	}
	
	public RegeneratingTheLivingWorldPage deleteActionPlanInThrivingCommunitiesPage() {
		
		sleep(3000);
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab3.Xpath"))));
		deleteActionPlanForAllKeyMetrics();

		return new RegeneratingTheLivingWorldPage();

	}

}
