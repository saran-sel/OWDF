package pages.ActionPlan;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooks.TestNgHooksForActionPlan;
import services.AtSourceValidations;

public class FarmerGroupSummaryPage extends TestNgHooksForActionPlan {


	AtSourceValidations atsourceValidations = new AtSourceValidations();

	public FarmerGroupSummaryPage getListOfKMsForSupplyChain() {

		AtSourceValidations atsourceValidations = new AtSourceValidations();
		List<HashMap<String, Object>> fgCompleteData = atsourceValidations.getExcelData("./reference/FG.xlsx");
		List<HashMap<String, Object>> kmDetailsData = atsourceValidations.getExcelData("./reference/KMDetails.xlsx");
		for(HashMap<String, Object> map : fgCompleteData) {
			if(map.get("PRODUCT").equals(getProduct()) && map.get("Origin").equals(getOrigin()) && map.get("FARMERGROUP").equals(getFg())) {
				for(String km : map.keySet()) {
					if(km.contains("-")) {
						for(HashMap<String, Object> temp : kmDetailsData) {
							if(temp.get("KMNomeClature").toString().equals(km)) {
								System.out.println("Description of KM - "+km+"-- is ---"+temp.get("KMDescription"));
							}
						}
					}
				}
			}
		}

		return null;
	}


	public ProsperousFarmersAndFoodSystemsPage addActionPlanInFarmerGroupSummaryPage() {

		sleep(3000);
		List<WebElement> KMsOnScreen = getDriver().findElements(By.xpath(locators.getProperty("ActionPlan.GetKMFromAP.Xpath")));
		boolean exist = atsourceValidations.verifyKMfromExcel(KMsOnScreen,getProduct(),getOrigin(),getFg());
		System.out.println(exist);
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab1.Xpath"))));

		int actionPlanExisting = getDriver()
				.findElements(By.xpath(locators.getProperty("PillarsTab.ViewButton.Xpath"))).size();

		if(actionPlanExisting >= 1) {
			getActionPlanExistingAndDelete();
			createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());
		}else {
			createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());
		}

		return new ProsperousFarmersAndFoodSystemsPage();
	}

	public ProsperousFarmersAndFoodSystemsPage editActionPlanInFarmerGroupSummaryPage() {

		sleep(3000);
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab1.Xpath"))));
		editActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());

		return new ProsperousFarmersAndFoodSystemsPage();

	}

	public ProsperousFarmersAndFoodSystemsPage deleteActionPlanInFarmerGroupSummaryPage() {

		deleteActionPlanForAllKeyMetrics();

		return new ProsperousFarmersAndFoodSystemsPage();

	}


}
