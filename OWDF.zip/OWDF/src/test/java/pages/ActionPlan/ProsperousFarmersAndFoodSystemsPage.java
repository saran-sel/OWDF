package pages.ActionPlan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooks.TestNgHooksForActionPlan;
import services.AtSourceValidations;

public class ProsperousFarmersAndFoodSystemsPage extends TestNgHooksForActionPlan {

	AtSourceValidations atsourceValidations = new AtSourceValidations();

	public ThrivingCommunitiesPage addActionPlanInProsperousFarmersAndFoodSystemsPage() {

		sleep(3000);
		List<WebElement> KMsOnScreen = getDriver().findElements(By.xpath(locators.getProperty("ActionPlan.GetKMFromAP.Xpath")));
		boolean exist = atsourceValidations.verifyKMfromExcel(KMsOnScreen,getProduct(),getOrigin(),getFg());
		
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab2.Xpath"))));
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab2.Xpath"))));

		int actionPlanExisting = getDriver()
				.findElements(By.xpath(locators.getProperty("PillarsTab.ViewButton.Xpath"))).size();

		if(actionPlanExisting >= 1) {

			getActionPlanExistingAndDelete();
			createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());

		}else {
			createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());
		}

		return new ThrivingCommunitiesPage();
	}

	public ThrivingCommunitiesPage editActionPlanInProsperousFarmersAndFoodSystemsPage() {

		sleep(3000);
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab2.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab2.Xpath"))));

		editActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());

		return new ThrivingCommunitiesPage();

	}

	public ThrivingCommunitiesPage deleteActionPlanInProsperousFarmersAndFoodSystemsPage() {

		sleep(3000);
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab2.Xpath"))));
		deleteActionPlanForAllKeyMetrics();

		return new ThrivingCommunitiesPage();

	}




}
