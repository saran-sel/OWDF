package pages.ActionPlan;

import org.openqa.selenium.By;

import hooks.TestNgHooksForActionPlan;
import services.AtSourceValidations;

public class FarmerGroupsPage extends TestNgHooksForActionPlan {

	AtSourceValidations ats = new AtSourceValidations();

	public FarmerGroupSummaryPage selectNoOfSupplyChain() {

		getOptionsAndSelectInSequence(locators.getProperty("FarmerGroupPage.DropdownValues.Xpath"));
		click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.ProductDropdown.Id"))));
		String product = getAttribute(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.ProductDropdown.Id"))),
				"placeholder");
		click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.OriginDropdown.Id"))));
		String origin =getAttribute(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.OriginDropdown.Id"))),
				"placeholder");
		click(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.FGDropdown.Id"))));
		String fg =getAttribute(getDriver().findElement(By.id(locators.getProperty("FarmerGroupPage.FGDropdown.Id"))),
				"placeholder");

		click(getDriver().findElement(By.xpath(locators.getProperty("FarmerGroupPage.SearchButton.Xpath"))));
		FarmerGroupSummaryPage farmerPage = new FarmerGroupSummaryPage();
		farmerPage.setProduct(product);
		farmerPage.setOrigin(origin);
		farmerPage.setFg(fg);
		return farmerPage;	
	}
	
	




}
