package pages.ActionPlan;

import org.openqa.selenium.By;

import hooks.TestNgHooksForActionPlan;
import services.AtSourceValidations;

public class ActionPlansHomePage extends TestNgHooksForActionPlan {
	
	AtSourceValidations ats = new AtSourceValidations();
	
	
	public FarmerGroupsPage clickAdd() {
		
		click(getDriver().findElement(By.xpath(locators.getProperty("HomePage.AddButton.Xpath"))));
		sleep(3000);
		return new FarmerGroupsPage();

	}
	
	

}
