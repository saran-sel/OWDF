package pages.ActionPlan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooks.TestNgHooksForActionPlan;

public class RegeneratingTheLivingWorldPage extends TestNgHooksForActionPlan {

	public RegeneratingTheLivingWorldPage addActionPlanInRegeneratingTheLivingWorldPage() {

		sleep(3000);
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab4.Xpath"))));
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab4.Xpath"))));

		List<WebElement> innerTabs = getDriver().findElements(By.xpath(locators.getProperty("PillarsTab.Tab4.InnerSections.Xpath")));

		for (int i = 1; i <= innerTabs.size(); i++) {

			sleep(3000);
			click(getDriver().findElement(By.xpath("("+locators.getProperty("PillarsTab.Tab4.InnerSections.Xpath")+")["+i+"]")));

			int actionPlanExisting = getDriver()
					.findElements(By.xpath(locators.getProperty("PillarsTab.ViewButton.Xpath"))).size();

			if(actionPlanExisting >= 1) {

				getActionPlanExistingAndDelete();
				createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());

			}else {
				createActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());
			}

		}

		return this;
	}

	public RegeneratingTheLivingWorldPage editActionPlanInRegeneratingTheLivingWorldPage() {

		sleep(3000);
		String tabText = getText(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab4.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab4.Xpath"))));

		List<WebElement> innerTabs = getDriver().findElements(By.xpath(locators.getProperty("PillarsTab.Tab4.InnerSections.Xpath")));

		for (int i = 1; i <= innerTabs.size(); i++) {
			sleep(3000);
			click(getDriver().findElement(By.xpath("("+locators.getProperty("PillarsTab.Tab4.InnerSections.Xpath")+")["+i+"]")));
			editActionPlanForAllKeyMetrics(tabText,getProduct(),getOrigin(),getFg());
		}

		return this;

	}

	public RegeneratingTheLivingWorldPage deleteActionPlanInRegeneratingTheLivingWorldPage() {

		sleep(3000);
		click(getDriver().findElement(By.xpath(locators.getProperty("PillarsTab.Tab4.Xpath"))));
		List<WebElement> innerTabs = getDriver().findElements(By.xpath(locators.getProperty("PillarsTab.Tab4.InnerSections.Xpath")));

		for (int i = 1; i <= innerTabs.size(); i++) {
			sleep(3000);
			click(getDriver().findElement(By.xpath("("+locators.getProperty("PillarsTab.Tab4.InnerSections.Xpath")+")["+i+"]")));
			deleteActionPlanForAllKeyMetrics();
		}

		return this;

	}

}
