package pages.ActionPlan;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Sleeper;

import hooks.TestNgHooksForActionPlan;
import io.cucumber.java.en.When;
import services.AtSourceValidations;

public class AtSourcePlusPage extends TestNgHooksForActionPlan {

	AtSourceValidations ats = new AtSourceValidations();

	@When("Select Product dropdown and compare values with excel  (.*)$")
	public AtSourcePlusPage selectProductAndCompareWithExcel() {

		try {
			click(getDriver().findElement(By.xpath(locators.getProperty("DashboardPage.AtSourcePlus.Xpath"))));
			click(getDriver().findElement(By.className(locators.getProperty("DashboardPage.PlanetTab.ClassName"))));
			boolean isEqual = getAllOptionsFromDropDown(getDriver()
					.findElement(By.xpath(locators.getProperty("DashboardPage.ProductDropdown.Xpath")))).equals(
							ats.getListOfProductsFromExcel());
			System.out.println(isEqual);
			reportStep("Dropdown values and Excel values validation performed", isEqual ? "PASS" : "FAIL");
		} catch (Exception e) {
			reportStep("Dropdown values and Excel values mismatch","FAIL");
			e.printStackTrace();
		}

		return this;
	}

	@When("Select dropdown values(.*)$")
	public AtSourcePlusPage checkAbsoluteAndIntensityValues() {

		try {

			click(getDriver().findElement(By.xpath(locators.getProperty("DashboardPage.AtSourcePlus.Xpath"))));
			click(getDriver().findElement(By.className(locators.getProperty("DashboardPage.PlanetTab.ClassName"))));

			ArrayList<String> listOfProducts = getAllOptionsFromDropDown(getDriver()
					.findElement(By.xpath(locators.getProperty("DashboardPage.ProductDropdown.Xpath"))));
			//listOfProducts.remove("Select a product");
			for (int i = 0; i < listOfProducts.size(); i++) {
				selectDropDownUsingVisibleText(getDriver()
						.findElement(By.xpath(locators.getProperty("DashboardPage.ProductDropdown.Xpath"))),
						listOfProducts.get(i));

				ArrayList<String> listOfOrigin = getAllOptionsFromDropDown(getDriver()
						.findElement(By.xpath(locators.getProperty("DashboardPage.Origin.Xpath"))));
				//listOfOrigin.remove("Select an origin");
				//System.out.println(listOfOrigin.size());
				for (int j = 0; j < listOfOrigin.size(); j++) {
					selectDropDownUsingVisibleText(getDriver()
							.findElement(By.xpath(locators.getProperty("DashboardPage.Origin.Xpath"))),
							listOfOrigin.get(j));

					ArrayList<String> listOfDestination = getAllOptionsFromDropDown(getDriver()
							.findElement(By.xpath(locators.getProperty("DashboardPage.Destination.Xpath"))));
					//listOfDestination.remove("Select a destination");
					for (int k = 0; k < listOfDestination.size(); k++) {
						System.out.println("founded desti is:"+listOfDestination.get(k));
						System.out.println("K value is"+k);

						selectDropDownUsingVisibleText(getDriver()
								.findElement(By.xpath(locators.getProperty("DashboardPage.Destination.Xpath"))),
								listOfDestination.get(k));
						click(getDriver().findElement(By.xpath(locators.getProperty("DashboardPage.CFPButton.Xpath"))));

						String selectedProduct = getSelectedOption(getDriver().findElement(
								By.xpath(locators.getProperty("DashboardPage.ProductDropdown.Xpath"))));
						String selectedOrigin = getSelectedOption(getDriver().findElement(
								By.xpath(locators.getProperty("DashboardPage.Origin.Xpath"))));
						String selectedDestination = getSelectedOption(getDriver().findElement(
								By.xpath(locators.getProperty("DashboardPage.Destination.Xpath"))));

						System.out.println("Iam:  "+selectedProduct);
						System.out.println("Iam:  "+selectedOrigin);
						System.out.println("Iam:  "+selectedDestination);

						String totalIntensityWeb = getText(getDriver().findElement(By.xpath(locators.getProperty("ClimateAction.Intensity.Xpath"))));
						Object totalIntensityExcel = AtSourceValidations.returnvalueForKey(selectedProduct, selectedOrigin, selectedDestination, "CC-TOTAL");
						
						
						String agricultureCCTotalWeb = getText(getDriver().findElement(By.xpath(locators.getProperty("ClimateAction.AgricultureTotal.Xpath"))));
						Object agricultureCCTotalExcel = AtSourceValidations.returnvalueForKey(selectedProduct, selectedOrigin, selectedDestination, "CC-A-TOTAL");
						
						
						System.out.println(totalIntensityWeb);
						System.out.println(totalIntensityExcel);

						System.out.println(agricultureCCTotalWeb);
						System.out.println(agricultureCCTotalExcel);

						if(k==0) {
							break;
						}
					}
					if(j==0) {
						break;
					}
				}
				if(i==0) {
					break;
				}
			}
		}catch(Exception e) {
		}

		return this;


	}





}
