package pages.AtSource;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;

import hooks.TestNgHooksForAtSource;
import services.AtSourceValidations;

public class FarmerGroupSummaryPage extends TestNgHooksForAtSource  {

	AtSourceValidations atsource = new AtSourceValidations();
	ArrayList listOfKMBasedOnSheetName = atsource.getListOfKMBasedOnSheetName("FARMER GROUP SUMMARY");


	public FarmerGroupSummaryPage verifyActionPlanCountOnFG() {

		try {
			for (int i = 0; i < listOfKMBasedOnSheetName.size(); i++) {

				System.out.println(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
				+"')]/following::div/img)[1]");
				verifyDisplayed(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
				+"')]/following::div/img)[1]")));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public ProsperousFarmersAndFoodSystemsPage verifyTitleAndDescOnFG() {

		HashMap<String, HashMap<String, HashMap<String, String>>> excelKms = atsource.getExcelKMValues();
		
		try {
			for (int i = 0; i < listOfKMBasedOnSheetName.size(); i++) {
				click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
				+"')]/following::div/img)[1]")));
				String title = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.Title.Xpath"))));
				String desc = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.Description.Xpath"))));
				System.out.println("appTitle-------"+title);
				System.out.println("appDesc-------"+desc);
				
				boolean result = atsource.findMatchForTitleDesc(excelKms, "FARMER GROUP SUMMARY", listOfKMBasedOnSheetName.get(i).toString(), title, desc);
				System.out.println("result-------"+result);
				
				click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.CloseTile.Xpath"))));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ProsperousFarmersAndFoodSystemsPage();


	}
	
	public  ProsperousFarmersAndFoodSystemsPage verifyActionPlanDeletedInFarmerGroupSummaryPage() {
		
		verifyNonExistenceOfActionPlan(getDriver().findElements(By.xpath(locators.getProperty("Atsource.VerifyDelete.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.ProsperousFarmersTab.Xpath"))));
		
		return new ProsperousFarmersAndFoodSystemsPage();
		
	}



}
