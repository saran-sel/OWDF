package pages.AtSource;

import org.openqa.selenium.By;

import hooks.TestNgHooksForAtSource;

public class AtSourceHomePage extends TestNgHooksForAtSource {

	
	public AtsourcePlusPage redirectToAtSourcePlus() {
		sleep(30000);
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.HomePage.ASPlus.Xpath"))));
		return new AtsourcePlusPage();
		
	}


}
