package pages.AtSource;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;

import hooks.TestNgHooksForAtSource;
import services.AtSourceValidations;

public class ProsperousFarmersAndFoodSystemsPage  extends TestNgHooksForAtSource {

	AtSourceValidations atsource = new AtSourceValidations();
	ArrayList<String> listOfKMBasedOnSheetName = atsource.getListOfKMBasedOnSheetName("PROSPEROUS FARMERS & FOOD SYSTE");

	public ProsperousFarmersAndFoodSystemsPage verifyActionPlanCountOnPFS() {

		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.ProsperousFarmersTab.Xpath"))));

		try {
			for (int i = 0; i < listOfKMBasedOnSheetName.size(); i++) {

				System.out.println(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
				+"')]/following::div/img)[1]");
				try {
					//Workaround//
					if(listOfKMBasedOnSheetName.get(i)
							.equalsIgnoreCase("Olam employees trained on health & safety practices")) {
						verifyDisplayed(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
						+"')])[2]//following::div/img")));
					}else {
						verifyDisplayed(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
						+"')]/following::div/img)[1]")));
					}


				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public ThrivingCommunitiesPage verifyTitleAndDescOnPFS() {

		HashMap<String, HashMap<String, HashMap<String, String>>> excelKms = atsource.getExcelKMValues();
		try {
			for (int i = 0; i < listOfKMBasedOnSheetName.size(); i++) {
				try {
					try {
						if(listOfKMBasedOnSheetName.get(i)
								.equalsIgnoreCase("Olam employees trained on health & safety practices")) {
							click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
							+"')])[2]//following::div/img")));
						}else {
							click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")
									+ listOfKMBasedOnSheetName.get(i) + "')]/following::div/img)[1]")));
						}

					} catch (Exception e) {
						// TODO: handle exception
					}
					String title = getText(
							getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.Title.Xpath"))));
					String desc = getText(
							getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.Description.Xpath"))));
					System.out.println("appTitle-------" + title);
					System.out.println("appDesc-------" + desc);
					boolean result = atsource.findMatchForTitleDesc(excelKms, "PROSPEROUS FARMERS & FOOD SYSTE",
							listOfKMBasedOnSheetName.get(i).toString(), title, desc);
					System.out.println("result-------" + result);
					click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.CloseTile.Xpath"))));
				} catch (Exception e) {
					// TODO: handle exception
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new ThrivingCommunitiesPage();


	}

	public  ThrivingCommunitiesPage verifyActionPlanDeletedInProsperousFarmersPage() {

		verifyNonExistenceOfActionPlan(getDriver().findElements(By.xpath(locators.getProperty("Atsource.VerifyDelete.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.ThrivingCommunitiesTab.Xpath"))));

		return new ThrivingCommunitiesPage();

	}


}
