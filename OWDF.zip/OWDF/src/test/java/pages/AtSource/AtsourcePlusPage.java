package pages.AtSource;

import org.openqa.selenium.By;

import hooks.TestNgHooksForAtSource;
import services.AtSourceValidations;

public class AtsourcePlusPage  extends TestNgHooksForAtSource {

	AtSourceValidations atsource = new AtSourceValidations();

	public AtsourcePlusPage selectProductOriginAndSearch() {
		
		System.out.println("----------------------------------------");
		System.out.println(locators.getProperty("AtSource.ProductOption.Xpath")
				+atsource.getSupplyChainFromExcel().get("product")+"']");
		System.out.println(locators.getProperty("AtSource.OriginOption.Xpath")
				+atsource.getSupplyChainFromExcel().get("origin")+"']");
		System.out.println("----------------------------------------");

		click(getDriver().findElement(By.id(locators.getProperty("AtSource.ProductDropdown.Id"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.ProductOption.Xpath")
				+atsource.getSupplyChainFromExcel().get("product")+"']")));
		click(getDriver().findElement(By.id(locators.getProperty("Atsource.OriginDropdown.Id"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.OriginOption.Xpath")
				+atsource.getSupplyChainFromExcel().get("origin")+"']")));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.ApplyButton.Xpath"))));

		return this;
	}

	public FarmerGroupSummaryPage selectFGFromGridAndSubmit() {

		click(getDriver().findElement(By.className(locators.getProperty("Atsource.ExpandFarmerGroup.ClassName"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.SelectFGFromTable.Xpath")
				+atsource.getSupplyChainFromExcel().get("fg")+"']/../../th/span")));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.SubmitButton.Xpath"))));

		return new FarmerGroupSummaryPage() ;
	}


}
