package pages.AtSource;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;

import hooks.TestNgHooksForAtSource;
import services.AtSourceValidations;

public class RegeneratingTheLivingWorldPage  extends TestNgHooksForAtSource {

	AtSourceValidations atsource = new AtSourceValidations();
	ArrayList<String> listOfKMBasedOnSheetName = atsource.getListOfKMBasedOnSheetName("REGENERATING THE LIVING WORLD");

	public RegeneratingTheLivingWorldPage redirectToAtSourcePlus() {
		sleep(30000);
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.HomePage.ASPlus.Xpath"))));
		return this;

	}

	public RegeneratingTheLivingWorldPage selectProductOriginAndSearch() {

		click(getDriver().findElement(By.id(locators.getProperty("AtSource.ProductDropdown.Id"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.ProductOption.Xpath"))));
		click(getDriver().findElement(By.id(locators.getProperty("Atsource.OriginDropdown.Id"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.OriginOption.Xpath"))));	
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.ApplyButton.Xpath"))));

		return this;
	}

	public RegeneratingTheLivingWorldPage selectFGFromGridAndSubmit() {

		click(getDriver().findElement(By.className(locators.getProperty("Atsource.ExpandFarmerGroup.ClassName"))));
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.SelectFGFromTable.Xpath"))));
		//click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.SubmitButton.Xpath"))));

		return this ;
	}

	public RegeneratingTheLivingWorldPage selectSupplyChainAndClickCalculate() {

		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Xpath"))));		
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.ProductDropdown.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("AtSource.ProductOption.Xpath")
				+atsource.getSupplyChainFromExcel().get("product")+"']")));	
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.FGDropdown.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.FGOption.Xpath")
				+atsource.getSupplyChainFromExcel().get("fg")+"']")));	
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.DestinationDropdown.Xpath"))));		
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.DestinationOption.Xpath"))));
		click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.CPButton.Xpath"))));

		return this;
	}



	public RegeneratingTheLivingWorldPage verifyActionPlanCountOnRegen() {

		for (int i = 0; i < listOfKMBasedOnSheetName.size(); i++) {

			sleep(3000);
			System.out.println(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
			+"')]/following::div/img)[1]");
			verifyDisplayed(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")+listOfKMBasedOnSheetName.get(i)
			+"')]/following::div/img)[1]")));
		}
		return this;
	}

	public RegeneratingTheLivingWorldPage verifyTitleAndDescOnRegen() {

		HashMap<String, HashMap<String, HashMap<String, String>>> excelKms = atsource.getExcelKMValues();
		for (String obj : listOfKMBasedOnSheetName) {
			System.out.println("Actual from excel:::::"+obj);
		}
		listOfKMBasedOnSheetName.set(0, "Absolute");
		listOfKMBasedOnSheetName.set(1, "Intensity");
		listOfKMBasedOnSheetName.set(2, "Agriculture");
		listOfKMBasedOnSheetName.set(3, "Processing");
		listOfKMBasedOnSheetName.set(4, "Transport");

		for (String obj : listOfKMBasedOnSheetName) {
			System.out.println("After change:::::"+obj);
		}

		for (int i = 0; i < listOfKMBasedOnSheetName.size(); i++) {
			String title;
			String desc;

			if (listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Processing")) {
				System.out.println("Inside Processing for flip");
				click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")
						+ listOfKMBasedOnSheetName.get(i) + "')]/following::div/img)[2]")));
			}else if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Transport")) {
				System.out.println("Inside Transport for flip");
				click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")
						+ listOfKMBasedOnSheetName.get(i) + "')]/following::div/img)[3]")));
			}else {
				System.out.println("Inside common:::"+ listOfKMBasedOnSheetName.get(i));
				click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.FGS.FlipIcon.Xpath")
						+ listOfKMBasedOnSheetName.get(i) + "')]/following::div/img)[1]")));
			}

			if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Agriculture")) {
				title = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::p[2]")));
				desc = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::p[3]")));
				System.out.println("AgriTitle:::"+title+"-----"+"AgriDesc:::"+desc);

			}else if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Processing")) {
				title = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::p[5]")));
				desc = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::p[6]")));
				System.out.println("ProcTitle:::"+title+"-----"+"ProcDesc:::"+desc);

			}else if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Transport")) {
				title = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::p[8]")));
				desc = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::p[9]")));
				System.out.println("TransTitle:::"+title+"-----"+"TransDesc:::"+desc);
			}else {
				title = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::div/img[1]/following::div/p")));
				desc = getText(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.Title.Xpath")+
						listOfKMBasedOnSheetName.get(i)+"')]/following::div/img[1]/following::div/p[2]")));
				System.out.println(listOfKMBasedOnSheetName.get(i)+title+"-----"+listOfKMBasedOnSheetName.get(i)+desc);
			}


			System.out.println("appTitle-------"+title);
			System.out.println("appDesc-------"+desc);

			boolean result = atsource.findMatchForTitleDesc(excelKms, "REGENERATING THE LIVING WORLD", listOfKMBasedOnSheetName.get(i).toString().toUpperCase(), title, desc);
			System.out.println("result-------"+result);

			sleep(3000);

			if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Processing")) {
				click(getDriver().findElement(By.xpath("//p[text()='"+title+"']/preceding-sibling::p")));
			}else if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Transport")) {
				click(getDriver().findElement(By.xpath("//p[text()='"+title+"']/preceding-sibling::p")));
			}else if(listOfKMBasedOnSheetName.get(i).equalsIgnoreCase("Agriculture")) {
				click(getDriver().findElement(By.xpath("//p[text()='"+title+"']/preceding-sibling::p")));
			}else {
				System.out.println(locators.getProperty("Atsource.RegenTab.CloseTile.Xpath")
						+listOfKMBasedOnSheetName.get(i)+"')]/following::div/img)[1]/following::div/span[@class='flipclose']");
				click(getDriver().findElement(By.xpath(locators.getProperty("Atsource.RegenTab.CloseTile.Xpath")
						+listOfKMBasedOnSheetName.get(i)+"')]/following::div/img)[1]/following::div/span[@class='flipclose']")));
			}


		}

		return this;


	}

	public  RegeneratingTheLivingWorldPage verifyActionPlanDeletedInRegeneratingPage() {

		verifyNonExistenceOfActionPlan(getDriver().findElements(By.xpath(locators.getProperty("Atsource.VerifyDelete.Xpath"))));	

		return this;

	}


}
