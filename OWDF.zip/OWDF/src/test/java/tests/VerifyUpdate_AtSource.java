package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooksForAtSource;
import pages.ActionPlan.ActionPlansHomePage;
import pages.ActionPlan.FarmerGroupSummaryPage;
import pages.ActionPlan.FarmerGroupsPage;
import pages.AtSource.AtSourceHomePage;
import pages.AtSource.RegeneratingTheLivingWorldPage;

public class VerifyUpdate_AtSource extends TestNgHooksForAtSource  {


	ActionPlansHomePage homePage;
	FarmerGroupsPage fgPage;
	FarmerGroupSummaryPage fgsPage;

	@BeforeTest
	public void setexcelData() {
		testCaseName = "Action Plan Automation";
		testDescription = "Verify Update on AtSource";
		category = "Sanity";
		authors = "Saravanan";  
		dataSheetName = "NA";
		nodes = "AtSource Test Steps";
	}

	@Test(groups="Verify_Update")
	public void verifyActionPlanCreation() {

		new AtSourceHomePage()
		.redirectToAtSourcePlus()
		.selectProductOriginAndSearch()
		.selectFGFromGridAndSubmit()
		.verifyActionPlanCountOnFG()
		.verifyTitleAndDescOnFG()
		.verifyActionPlanCountOnPFS()
		.verifyTitleAndDescOnPFS()
		.verifyActionPlanCountOnTC()
		.verifyTitleAndDescOnTC()
		.selectSupplyChainAndClickCalculate()
		.verifyTitleAndDescOnRegen();

	}



}
