package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooksForActionPlan;
import pages.ActionPlan.ActionPlansHomePage;

public class ActionPlanEdit extends TestNgHooksForActionPlan {

	@BeforeTest
	public void setexcelData() {
		testCaseName = "Action Plan Automation";
		testDescription = "Update ActionPlan";
		category = "Sanity";
		authors = "Saravanan";  
		dataSheetName = "NA";
		nodes = "AtSource Test Steps";
	}

	@Test(groups="AP_Edit")
	public void editActionPlan() {
		
		System.out.println("IM AP Edit");

		new ActionPlansHomePage()
		.clickAdd()
		.selectNoOfSupplyChain()
		.editActionPlanInFarmerGroupSummaryPage()
		.editActionPlanInProsperousFarmersAndFoodSystemsPage()
		.editActionPlanInThrivingCommunitiesPage()
		.editActionPlanInRegeneratingTheLivingWorldPage();
		;
	}

}
