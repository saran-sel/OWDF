package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooksForActionPlan;
import pages.ActionPlan.ActionPlansHomePage;

public class ActionPlanDelete extends TestNgHooksForActionPlan {

	@BeforeTest
	public void setexcelData() {
		testCaseName = "Action Plan Automation";
		testDescription = "Delete ActionPlan";
		category = "Sanity";
		authors = "Saravanan";  
		dataSheetName = "NA";
		nodes = "AtSource Test Steps";
	}

	@Test(groups="AP_Delete")
	public void deleteActionPlan() {

		new ActionPlansHomePage()
		.clickAdd()
		.selectNoOfSupplyChain()
		.deleteActionPlanInFarmerGroupSummaryPage()
		.deleteActionPlanInProsperousFarmersAndFoodSystemsPage()
		.deleteActionPlanInThrivingCommunitiesPage()
		.deleteActionPlanInRegeneratingTheLivingWorldPage();

	}

}