package tests;

import java.util.HashMap;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooksForActionPlan;
import pages.ActionPlan.AtSourcePlusPage;
import services.AtSourceValidations;

public class AtSourceBasicTest extends TestNgHooksForActionPlan {

	@BeforeTest
	public void setData() {
		testCaseName = "AtSource Basic Test";
		testDescription = "Login to AtSource.io";
		category = "smoke";
		authors = "Saravanan";  
		dataSheetName = "NA";
		nodes = "AtSource";
	}

	@Test
	public void testAtSource() {

		new AtSourcePlusPage()
		
		.checkAbsoluteAndIntensityValues();
	}

}
