package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooksForActionPlan;
import pages.ActionPlan.ActionPlansHomePage;
import pages.ActionPlan.FarmerGroupSummaryPage;
import pages.ActionPlan.FarmerGroupsPage;

public class ActionPlanCreate extends TestNgHooksForActionPlan {

	ActionPlansHomePage homePage;
	FarmerGroupsPage fgPage;
	FarmerGroupSummaryPage fgsPage;

	@BeforeTest
	public void setexcelData() {
		testCaseName = "Action Plan Automation";
		testDescription = "Create ActionPlan";
		category = "Sanity";
		authors = "Saravanan";  
		dataSheetName = "NA";
		nodes = "AtSource Test Steps";
	}

	@Test(groups="AP_Create")

	public void createActionPlan() {
		
		new ActionPlansHomePage()
		.clickAdd()
		.selectNoOfSupplyChain()
		.addActionPlanInFarmerGroupSummaryPage()
		.addActionPlanInProsperousFarmersAndFoodSystemsPage()
		.addActionPlanInThrivingCommunitiesPage()
		.addActionPlanInRegeneratingTheLivingWorldPage();

	}

}
